﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZeldaFullEditor
{
    public enum Background2
    {
        Off, Parallax, Dark, OnTop, Translucent, Addition, Normal, Transparent, DarkRoom //TODO : Determine if DarkRoom will stay there or not
    }
}
