﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZeldaFullEditor
{
    public enum ObjectMode
    {
        Bg1mode, Bg2mode, Bg3mode, Bgallmode, Spritemode, Itemmode, Chestmode, Blockmode, Torchmode, Doormode,Warpmode
    }
}
